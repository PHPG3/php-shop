<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>后台欢迎页</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/content.css" />
</head>
<body marginwidth="0" marginheight="0">
	<div class="container">
			<div class="public-content">
				</div>
					<p style="width: 100%;text-align: center; padding: 50px 0; font-size: 25px; color: green;">
					管理员 你好！ 欢迎登陆PHP大作业商城后台！<br><br>
					修改会员信息、商品信息、数据库信息之前记得备份数据！<br><br>
					小组成员：林源 谭贤政 崔洪铭<br><br>

					</p>
				</div>
			</div>
		</div>
	</div>	
</body>
</html>
