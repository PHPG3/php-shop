 <!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>商城后台管理系统</title>
		<style type="text/css">
		*{
			margin: 0px;
			padding: 0px;
		}
		.header{
			width:100%;
			height:100px;
			background-color:#33AECC;
			display:block;
			padding-bottom:0px;
		}
		.font{
			width: 250px;
			font-size: 30px;
			color:#FFFFFF; 
			padding-left: 150px;
			padding-top:25px; 
		}
		</style>
	</head>
	<body>
		<span class="header">
			<div class="font">雅妆后台管理系统</div>
		</span>
	</body>
</html>
